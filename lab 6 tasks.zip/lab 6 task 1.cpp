#include <iostream>
using namespace std;
 
struct Node {
    int data;
    Node* prev;
    Node* next;
};
 
class DoublyLinkedList {
private:
    Node* head;
public:
    DoublyLinkedList() {
        head = nullptr;
    }
 
    void insert(int value) {
        Node* newNode = new Node{value, nullptr, head};
        if (head != nullptr)
            head->prev = newNode;
        head = newNode;
    }
 
    void deleteAtBeginning() {
        if (head == nullptr) {
            cout << "List is empty!\n";
            return;
        }
        Node* temp = head;
        head = head->next;
        if (head) head->prev = nullptr;
        delete temp;
        cout << "Deleted node from the beginning.\n";
    }
 
    void deleteAfterValue(int value) {
        Node* temp = head;
        while (temp && temp->data != value)
            temp = temp->next;
 
        if (temp == nullptr || temp->next == nullptr) {
            cout << "Deletion not possible!\n";
            return;
        }
 
        Node* delNode = temp->next;
        temp->next = delNode->next;
        if (delNode->next)
            delNode->next->prev = temp;
        
        delete delNode;
        cout << "Deleted node after " << value << ".\n";
    }
 
    void display() {
        Node* temp = head;
        while (temp) {
            cout << temp->data << " <-> ";
            temp = temp->next;
        }
        cout << "NULL\n";
    }
};
 
int main() {
    DoublyLinkedList dll;
    dll.insert(70);
    dll.insert(45);
    dll.insert(30);
    dll.insert(10);
    
    cout << "Initial List: ";
    dll.display();
 
    dll.deleteAtBeginning();
    cout << "After deleting at beginning: ";
    dll.display();
 
    dll.deleteAfterValue(45);
    cout << "After deleting after 45: ";
    dll.display();
 
    return 0;
}

