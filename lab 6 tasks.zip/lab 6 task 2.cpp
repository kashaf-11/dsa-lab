#include <iostream>
#include <string>
using namespace std;
 
struct Player {
    string name;
    int score;
    Player* prev;
    Player* next;
};
 
class GolfTournament {
private:
    Player* head;
 
public:
    GolfTournament() {
        head = nullptr;
    }
 
    void addPlayer(string name, int score) {
        Player* newPlayer = new Player{name, score, nullptr, nullptr};
 
        if (head == nullptr || head->score >= score) {
            newPlayer->next = head;
            if (head) head->prev = newPlayer;
            head = newPlayer;
            return;
        }
 
        Player* temp = head;
        while (temp->next && temp->next->score < score)
            temp = temp->next;
 
        newPlayer->next = temp->next;
        if (temp->next) temp->next->prev = newPlayer;
        temp->next = newPlayer;
        newPlayer->prev = temp;
    }
 
    void deletePlayer(string name) {
        Player* temp = head;
        while (temp && temp->name != name)
            temp = temp->next;
 
        if (!temp) {
            cout << "Player not found!\n";
            return;
        }
 
        if (temp->prev) temp->prev->next = temp->next;
        if (temp->next) temp->next->prev = temp->prev;
        if (temp == head) head = temp->next;
 
        delete temp;
        cout << "Player " << name << " deleted.\n";
    }
 
    void displayList() {
        Player* temp = head;
        while (temp) {
            cout << temp->name << " (" << temp->score << ") -> ";
            temp = temp->next;
        }
        cout << "NULL\n";
    }
 
    void displayLowestScore() {
        if (!head) {
            cout << "No players!\n";
            return;
        }
        cout << "Lowest Score: " << head->name << " (" << head->score << ")\n";
    }
 
    void displayPlayersWithSameScore(int score) {
        Player* temp = head;
        bool found = false;
        while (temp) {
            if (temp->score == score) {
                cout << temp->name << " ";
                found = true;
            }
            temp = temp->next;
        }
        if (!found) cout << "No players with score " << score;
        cout << endl;
    }
 
    void displayBackwardFrom(string name) {
        Player* temp = head;
        while (temp && temp->name != name)
            temp = temp->next;
 
        if (!temp) {
            cout << "Player not found!\n";
            return;
        }
 
        cout << "Players behind " << name << ": ";
        while (temp) {
            cout << temp->name << " (" << temp->score << ") <- ";
            temp = temp->prev;
        }
        cout << "START\n";
    }
};
 
int main() {
    GolfTournament tournament;
    tournament.addPlayer("kashf", 72);
    tournament.addPlayer("komal", 85);
    tournament.addPlayer("sadaf", 72);
    tournament.addPlayer("nayab", 90);
    tournament.addPlayer("ayesha", 68);
 
    cout << "Players List:\n";
    tournament.displayList();
 
    cout << "\nDeleting ayesha...\n";
    tournament.deletePlayer("ayesha");
    tournament.displayList();
 
    cout << "\nLowest Score:\n";
    tournament.displayLowestScore();
 
    cout << "\nPlayers with score 72:\n";
    tournament.displayPlayersWithSameScore(72);
 
    cout << "\nDisplay Backward from sadaf:\n";
    tournament.displayBackwardFrom("sadaf");
 
    return 0;
}

