#include <iostream>
using namespace std;
int main() {
    int *ptr =NULL; 

    cout << "Enter a number: ";
    int num;
    cin >> num;

    ptr = &num;

    if (ptr !=NULL) {
    cout << "you entered " << *ptr << endl;
    } else {
    cout << "Pointer is null" <<endl;
    }

    return 0;
}

