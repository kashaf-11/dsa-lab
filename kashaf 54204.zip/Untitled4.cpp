
#include <iostream>
using namespace std;
int main() {
    // two integer variables
    int a,b;
    int* ptr;
     int**q = &ptr; 
    cout << "Enter the first integer: ";
    cin >> a;
ptr = &a; // address of 1
 cout << "First integer: " <<**q<< endl;
 
    cout << "Enter the second integer: ";
    cin >>b;

    //  address of 2
    ptr = &b; 
    cout << "Second integer: "<<**q<<endl;
    return 0;
}
