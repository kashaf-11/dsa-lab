#include <iostream>
using namespace std;
int main() {
	int a=5;
	float b=7.5;
	void *ptr=&a;
	ptr=&b;
	cout<<a<<endl;
	cout<<b<<endl;
	 return 0;
}
	
